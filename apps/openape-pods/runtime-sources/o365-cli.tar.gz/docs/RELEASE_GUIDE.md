# Release Guide: Azure App for Public Distribution

This guide shows you step by step how to register an Azure App so you can publicly release your CLI tool.

## TL;DR - What Do You Need?

| What | From Where | Example |
|------|------------|---------|
| **Client ID** | Azure App Registration | `12345678-abcd-1234-efgh-123456789012` |
| **Tenant ID** | Not needed | You use `common` for Multi-Tenant |
| **Client Secret** | Not needed | Public Clients don't need a secret |

For a public CLI tool, you only need **the Client ID**.

---

## Step 1: Open Azure Portal

1. Go to https://portal.azure.com
2. Sign in (Microsoft account, personal or business)

> You don't need **an Azure subscription** or **a credit card**.
> App Registrations are completely free.

---

## Step 2: Navigate to Microsoft Entra ID

**Option A: Via Search**
```
┌─────────────────────────────────────────────────────────────┐
│  🔍 Search: "entra"                                          │
│  ┌───────────────────────────────────────────────────────┐  │
│  │ 📁 Microsoft Entra ID                           ←──── │  │
│  │ 📁 Microsoft Entra ID Governance                      │  │
│  └───────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

**Option B: Via Menu**
- Click on the hamburger menu (☰) on the left
- Select "Microsoft Entra ID"

---

## Step 3: Create App Registration

1. In the left menu: **"App registrations"**
2. Click on **"+ New registration"** at the top

```
┌─────────────────────────────────────────────────────────────┐
│  Microsoft Entra ID │ App registrations                     │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  [+ New registration]  [Endpoints]  [Troubleshooting]       │
│                                                             │
│  Owned applications │ All applications                      │
│  ─────────────────────────────────────────────────────────  │
│  Display name          Application (client) ID    ...       │
│  (no apps yet)                                              │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Step 4: Fill Out Registration Form

### Name
```
┌─────────────────────────────────────────────────────────────┐
│  Name *                                                     │
│  ┌───────────────────────────────────────────────────────┐  │
│  │ O365 Mail CLI                                         │  │
│  └───────────────────────────────────────────────────────┘  │
│  The user-facing display name for this application          │
└─────────────────────────────────────────────────────────────┘
```

> Choose a descriptive name - users will see this during login!

### Supported account types

```
┌─────────────────────────────────────────────────────────────┐
│  Supported account types *                                  │
│                                                             │
│  ○ Accounts in this organizational directory only           │
│    (Single tenant)                                          │
│                                                             │
│  ● Accounts in any organizational directory                 │  ←── THIS OPTION!
│    (Any Microsoft Entra ID tenant - Multitenant)            │
│                                                             │
│  ○ Accounts in any organizational directory and             │
│    personal Microsoft accounts                              │
│                                                             │
│  ○ Personal Microsoft accounts only                         │
└─────────────────────────────────────────────────────────────┘
```

> **IMPORTANT**: Select the **second option** (Multitenant)!
>
> This allows users from ANY Microsoft 365 organization to sign in.

### Redirect URI

```
┌─────────────────────────────────────────────────────────────┐
│  Redirect URI (optional)                                    │
│                                                             │
│  ┌──────────────────────────┐ ┌───────────────────────────┐ │
│  │ Public client/native (m… ▼│ │ http://localhost          │ │
│  └──────────────────────────┘ └───────────────────────────┘ │
│                                                             │
│  We'll return the authentication response to this URI.      │
└─────────────────────────────────────────────────────────────┘
```

Settings:
- **Type**: `Public client/native (mobile & desktop)`
- **URI**: `http://localhost`

### Register

Click on **[Register]**

---

## Step 5: Copy Client ID

After registration, you'll see the overview page:

```
┌─────────────────────────────────────────────────────────────┐
│  O365 Mail CLI │ Overview                                   │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  Essentials                                                 │
│  ───────────────────────────────────────────────────────    │
│                                                             │
│  Display name              O365 Mail CLI                    │
│                                                             │
│  Application (client) ID   12345678-abcd-1234-efgh-...  📋  │  ←── THIS IS WHAT YOU NEED!
│                                                             │
│  Directory (tenant) ID     aaaaaaaa-bbbb-cccc-dddd-...      │  ←── NOT relevant
│                                                             │
│  Object ID                 xxxxxxxx-xxxx-xxxx-xxxx-...      │
│                                                             │
│  Supported account types   Multiple organizations           │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

**Copy the "Application (client) ID"** - this is the only value you need!

---

## Step 6: Enable Public Client Flow

1. Click on **"Authentication"** on the left
2. Scroll down to **"Advanced settings"**

```
┌─────────────────────────────────────────────────────────────┐
│  Advanced settings                                          │
│  ───────────────────────────────────────────────────────    │
│                                                             │
│  Allow public client flows                                  │
│                                                             │
│  Enables the following mobile and desktop flows:            │
│  • Device code flow                      ←── This is        │
│  • Username/password flow                    what we need!  │
│                                                             │
│  ┌─────────────────────────────────────────────┐            │
│  │ ○ No   ● Yes                                │  ←── YES!  │
│  └─────────────────────────────────────────────┘            │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

3. Set to **"Yes"**
4. Click **[Save]** at the top

---

## Step 7: Add API Permissions

1. Click on **"API permissions"** on the left
2. Click on **"+ Add a permission"**

```
┌─────────────────────────────────────────────────────────────┐
│  Request API permissions                                    │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  Microsoft APIs    APIs my organization uses    My APIs     │
│  ════════════════                                           │
│                                                             │
│  ┌─────────────────┐  ┌─────────────────┐                   │
│  │                 │  │                 │                   │
│  │  Microsoft      │  │  Office 365     │                   │
│  │  Graph          │  │  Exchange       │  ←── Alternative  │
│  │       ↑         │  │  Online         │                   │
│  │   THIS ONE!     │  │                 │                   │
│  └─────────────────┘  └─────────────────┘                   │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Select Microsoft Graph

1. Click on **"Microsoft Graph"**
2. Select **"Delegated permissions"** (not Application!)

```
┌─────────────────────────────────────────────────────────────┐
│  What type of permissions does your application require?    │
│                                                             │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  Delegated permissions                               │   │  ←── THIS ONE!
│  │  Your application needs to access the API as the     │   │
│  │  signed-in user.                                     │   │
│  └──────────────────────────────────────────────────────┘   │
│                                                             │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  Application permissions                             │   │
│  │  Your application runs as a background service       │   │
│  │  without a signed-in user.                           │   │
│  └──────────────────────────────────────────────────────┘   │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Search and Add Permissions

Search for these permissions one by one and enable them:

```
┌─────────────────────────────────────────────────────────────┐
│  🔍 Search: IMAP                                            │
│  ┌───────────────────────────────────────────────────────┐  │
│  │ ☑ IMAP.AccessAsUser.All                               │  │
│  │   Read and write access to mailboxes via IMAP.        │  │
│  └───────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│  🔍 Search: SMTP                                            │
│  ┌───────────────────────────────────────────────────────┐  │
│  │ ☑ SMTP.Send                                           │  │
│  │   Send emails from mailboxes using SMTP AUTH.         │  │
│  └───────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│  🔍 Search: offline                                         │
│  ┌───────────────────────────────────────────────────────┐  │
│  │ ☑ offline_access                                      │  │
│  │   Maintain access to data you have given access to.   │  │
│  │   (For Refresh Tokens)                                │  │
│  └───────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│  🔍 Search: User.Read                                       │
│  ┌───────────────────────────────────────────────────────┐  │
│  │ ☑ User.Read                                           │  │
│  │   Sign in and read user profile.                      │  │
│  │   (Optional, for email address)                       │  │
│  └───────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

Click on **[Add permissions]**

### Final Permission List

Your API Permissions should now look like this:

```
┌─────────────────────────────────────────────────────────────┐
│  API permissions                                            │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  API / Permissions name          Type        Status         │
│  ─────────────────────────────────────────────────────────  │
│  Microsoft Graph (4)                                        │
│    ├─ IMAP.AccessAsUser.All     Delegated   ✓ Granted      │
│    ├─ offline_access            Delegated   ✓ Granted      │
│    ├─ SMTP.Send                 Delegated   ✓ Granted      │
│    └─ User.Read                 Delegated   ✓ Granted      │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

> **No Admin Consent needed!**
> With "Delegated" permissions, each user can consent themselves.

---

## Step 8: Summary - What You Have

After all steps, you have:

```
┌─────────────────────────────────────────────────────────────┐
│  ✅ DONE - Your Release Configuration                       │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  Client ID:     12345678-abcd-1234-efgh-123456789012        │
│                 ↑                                           │
│                 This goes in your code / config             │
│                                                             │
│  Authority:     https://login.microsoftonline.com/common    │
│                 ↑                                           │
│                 "common" = Multi-Tenant, already in code    │
│                                                             │
│  Redirect URI:  http://localhost                            │
│                 ↑                                           │
│                 Not really used for Device Code Flow        │
│                                                             │
│  Permissions:   IMAP.AccessAsUser.All (Delegated)           │
│                 SMTP.Send (Delegated)                       │
│                 offline_access (Delegated)                  │
│                 User.Read (Delegated)                       │
│                                                             │
│  ❌ NOT NEEDED:                                             │
│     - Tenant ID (you use "common")                          │
│     - Client Secret (Public Client)                         │
│     - Admin Consent (Delegated Permissions)                 │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Step 9: Integrate into Code

### Option A: As Default in Code

Change in `internal/auth/oauth.go`:

```go
const (
    // Your own Client ID
    DefaultClientID = "12345678-abcd-1234-efgh-123456789012"

    // Multi-Tenant Authority (don't change!)
    Authority = "https://login.microsoftonline.com/common"
)
```

### Option B: As Configuration

Document in your README:

```markdown
## Configuration

Set your Client ID:

```bash
# Via environment variable
export O365_CLIENT_ID="12345678-abcd-1234-efgh-123456789012"

# Or via config file
echo 'client_id: "12345678-abcd-1234-efgh-123456789012"' >> ~/.o365-mail-cli/config.yaml
```
```

### Option C: Both (Recommended)

- Set your Client ID as default in code
- Allow users to configure their own

---

## Step 10: Test Before Release

```bash
# 1. Build with your Client ID
go build -o o365-mail-cli ./cmd/o365-mail-cli

# 2. Test login (with any M365 account)
./o365-mail-cli auth login

# 3. You should see:
# ╔════════════════════════════════════════════════════════════╗
# ║  To sign in, open this URL in your browser:               ║
# ║  https://microsoft.com/devicelogin                         ║
# ║                                                            ║
# ║  And enter this code:                                      ║
# ║                        ABC123                              ║
# ╚════════════════════════════════════════════════════════════╝

# 4. After browser login:
# ✓ Successfully logged in as user@example.com
```

---

## FAQ

### Do I need to configure something for each user?

**No!** Your app is Multi-Tenant. Any M365 user can sign in without you or their admin having to do anything.

### What does the user see on first login?

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│                    O365 Mail CLI                            │
│                                                             │
│  This app wants to:                                         │
│                                                             │
│  ✓ Access your emails via IMAP                             │
│  ✓ Send emails on your behalf                              │
│  ✓ Read your name and email address                        │
│                                                             │
│           [Accept]    [Cancel]                              │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Can an admin block access?

Yes, a tenant admin can:
1. Block the app for their tenant
2. Disable user consent entirely

But that's their decision, not your problem.

### Does the Azure App cost anything?

**No.** App Registrations are completely free, unlimited, forever.

### Can I change the app later?

Yes, you can change at any time:
- Name
- Add/remove permissions
- Change redirect URIs

The Client ID stays the same.

### What if I lose the Client ID?

You can always find it in Azure Portal at:
- Microsoft Entra ID → App registrations → Your App → Overview

---

## Checklist Before Release

- [ ] App Registration created
- [ ] Multi-Tenant enabled (Supported account types)
- [ ] Public Client Flow enabled
- [ ] Permissions added (IMAP, SMTP, offline_access)
- [ ] Client ID entered in code/config
- [ ] Login with test account works
- [ ] Reading emails works
- [ ] Sending emails works

---

## Your Data

Note your values here:

```
My Azure App
─────────────
App Name:    _______________________
Client ID:   _______________________
Created on:  _______________________
```

This Client ID goes in your release!
